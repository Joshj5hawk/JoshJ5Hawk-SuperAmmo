export declare enum Effect {
    Fracture = "Fracture",
    LightBleeding = "LightBleeding",
    HeavyBleeding = "HeavyBleeding"
}

export interface IGetInsuranceCostRequestData {
    traders: string[];
    items: string[];
}

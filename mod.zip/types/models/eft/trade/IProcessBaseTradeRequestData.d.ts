export interface IProcessBaseTradeRequestData {
    Action: string;
    type: string;
    tid: string;
}

export interface IGetLocationRequestData {
    crc: number;
    locationId: string;
    variantId: number;
}

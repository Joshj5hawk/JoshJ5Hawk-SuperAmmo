export interface IGetItemPriceResult {
    avg: number;
    min: number;
    max: number;
}

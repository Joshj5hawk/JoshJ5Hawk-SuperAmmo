export interface IPinDialogRequestData {
    dialogId: string;
}

export interface IRoute {
    aki: any;
}

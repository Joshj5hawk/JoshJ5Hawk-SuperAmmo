export declare class OnLoad {
    onLoad(): void;
    getRoute(): string;
}
